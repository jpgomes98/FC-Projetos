--PROJETO 2--

João Pedro Gomes ist187327
Mariana Silva ist187336

Grupo 2

Em conjunto com os ficheiros que contém o código dos programas, anexamos também alguns pdfs dos vários plots que fomos fazendo no Mathematica.

g2p2c0.cpp: Código feito antes da aula que utiliza o método de Runge-Kutta para resolver a equação diferencial do oscilador harmónico;

g2p2c1.cpp: Código que cria 3 ficheiros diferentes para wf=w0/3, wf=w0 e wf=3*w0. Os gráficos de x(t), v(t) e v(x) encontram-se na pasta como pdf;

g2p2c2.cpp: Criamos um código que utiliza o método de Runge Kutta para descrever mais geralmente a resolução de EDO's criando uma função que pode ser inserida na função que realiza o método de Runge-Kutta. Os dados são depois guardados numa matriz de memória dinâmica que é depois lida e escrita num ficheiro.

g2p2c3.cpp: Criamos um código que utiliza o método de Runge Kutta para descrever a trajetória de uma partícula tridimensional sujeita a uma força no eixo dos OxO.
Não conseguimos ter os resultados procurados mas não tinhamos mais tempo para debugging como tal decidimos apresentar o que já tínhamos.

g2p2c4.cpp: Utilizamos o código anterior para descrever a trajetória da Terra para vários valores de velocidade. Não tivemos tempo para completar como queríamos o programa dado que o projeto era extremamente extenso e necessita de muito tempo para debugging.

