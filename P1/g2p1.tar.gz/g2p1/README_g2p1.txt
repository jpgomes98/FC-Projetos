--PROJETO 1--

João Pedro Gomes ist187327
Mariana Silva ist187336

Grupo 2

Em conjunto com os ficheiros que contém o código dos programas, anexamos também alguns pdfs dos vários plots que fomos fazendo no Mathematica.

g2p1c1.cpp: Utilizamos uma variável declarada em vez da utilizada e alteramos o ciclo de while para for;

g2p1c2.cpp: Igual ao anterior apenas com input através do terminal e output para um ficheiro;

g2p1c3.cpp: Criamos um PRNG (pseudo gerador de sinais aleatórios) e verificamos a dispersão dos sinais gerados;

g2p1c4.cpp: Utilizamos o PRNG anterior e colocamos os resultados numa matrizque iguala o ficheiro anterior;

g2p1c5.cpp: Demonstramos a técnica de Monte Carlo aplicando o PRNG a uma função para determinar a área de um quarto de círculo;

g2p1c6.cpp: Verificamos a convergência criando um programa que faz mais iteradas e que revela se o programa converge para o valor de Pi.

	    A partir da análise do plot que obtivemos, concluimos que o método de Monte Carlo, apesar de estatístico, permite obter uma boa aproximação do valor real de Pi com um aumento do número de iterações uma vez que vai flutuando pouco em torno do valor pretendido.
